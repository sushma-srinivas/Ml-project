from flask import Flask, render_template, request, flash, redirect, url_for
import random

app = Flask(__name__)
app.secret_key = 'your-secret-key-change-in-production'

# Sample career data for recommendations
CAREERS = {
    'technology': [
        'Software Developer', 'Data Scientist', 'Cybersecurity Analyst', 
        'Web Developer', 'AI/ML Engineer', 'DevOps Engineer'
    ],
    'creative': [
        'Graphic Designer', 'Content Writer', 'Video Producer', 
        'UX/UI Designer', 'Marketing Specialist', 'Photographer'
    ],
    'business': [
        'Business Analyst', 'Project Manager', 'Sales Manager', 
        'Financial Analyst', 'Marketing Manager', 'Consultant'
    ],
    'healthcare': [
        'Nurse', 'Physical Therapist', 'Medical Technician', 
        'Healthcare Administrator', 'Pharmacist', 'Mental Health Counselor'
    ],
    'education': [
        'Teacher', 'Educational Counselor', 'Curriculum Developer', 
        'Training Coordinator', 'Academic Advisor', 'Learning Specialist'
    ]
}

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/recommend', methods=['GET', 'POST'])
def recommend():
    if request.method == 'POST':
        name = request.form.get('name', '').strip()
        interests = request.form.getlist('interests')
        experience = request.form.get('experience', '')
        
        if not name or not interests:
            flash('Please fill in all required fields.', 'error')
            return render_template('recommend.html')
        
        # Generate recommendations based on interests
        recommendations = []
        for interest in interests:
            if interest in CAREERS:
                # Get 2-3 random careers from each selected interest
                career_options = random.sample(CAREERS[interest], min(3, len(CAREERS[interest])))
                recommendations.extend(career_options)
        
        # Remove duplicates and limit to top 5
        recommendations = list(set(recommendations))[:5]
        
        return render_template('recommend.html', 
                             name=name, 
                             recommendations=recommendations,
                             show_results=True)
    
    return render_template('recommend.html')

@app.route('/contact', methods=['GET', 'POST'])
def contact():
    if request.method == 'POST':
        name = request.form.get('name', '').strip()
        email = request.form.get('email', '').strip()
        message = request.form.get('message', '').strip()
        
        if not all([name, email, message]):
            flash('Please fill in all fields.', 'error')
            return render_template('contact.html')
        
        # In a real app, you would send the email or save to database
        flash(f'Thank you {name}! Your message has been received. We\'ll get back to you soon.', 'success')
        return redirect(url_for('contact'))
    
    return render_template('contact.html')

if __name__ == '__main__':
    app.run(debug=True)